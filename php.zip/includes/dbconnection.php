<?php
$con=mysqli_connect("mysqldatabase.cyinc84ll8ue.ap-south-1.rds.amazonaws.com", "admin", "admin123", "detsdb", "3306");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>